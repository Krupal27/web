//Animation
AOS.init({
    duration: 3000,
});

// Redirect Other page

document.getElementById("Nav-home").addEventListener("click", function () {
    // console.log("called");
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/index.html#";
})

document.getElementById("Nav-about").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/About%20Us/index.html"
})

document.getElementById("Nav-team").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Team/index.html"
})

document.getElementById("Nav-services").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Services/index.html"
})

document.getElementById("Nav-event").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/News%20%26%20Events/index.html"
})

document.getElementById("Nav-contact").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Contact%20Us/index.html"
})


document.getElementById("th-home").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/index.html#"
})

document.getElementById("th-doctor").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Team/index.html"
})

document.getElementById("for-enquiry").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Enquiry/index.html#home"
})

document.getElementById("foot-doctor").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Team/index.html"
})

document.getElementById("foot-service").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Services/index.html"
})

document.getElementById("foot-event").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/News%20%26%20Events/index.html"
})

document.getElementById("foot-contact").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Contact%20Us/index.html"
})

document.getElementById("foot-call").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/index.html#"
})

document.getElementById("foot-fixed-contact").addEventListener("click", function () {
    window.location.href = "file:///d%3A/web/WebSite%20For%20Usine%20Health%20Care/Contact%20Us/index.html"
})